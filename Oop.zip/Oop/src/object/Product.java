package object;

public class Product {

    double price = 0;
    int quantity = 0;
    String name = "";

    public Product(){

    }

    public Product(String initialName, double initialPrice, int initialQuantity){

        this.price = initialPrice;
        this.quantity = initialQuantity;
        this.name = initialName;
    }

    public  void  printProduct (){

        System.out.println(this.name + ", " + this.price + ", " + this.quantity + "pcs.");
    }
}
