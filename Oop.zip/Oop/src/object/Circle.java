package object;

public class Circle {

        private double radius = 1.0;
        private String color = "red";

        public Circle() {

        }

        public Circle(double newRadius) {
            this.radius = newRadius;
        }

        public Circle(double newRadius, String newColor) {
            this.radius = newRadius;
            this.color = newColor;
        }

        public double getRadius() {
            return this.radius;
        }

        public String getColor() {
            return this.color;
        }

        public void setRadius(double newRadius) {
            this.radius = newRadius;
        }

        public void setColor(String newColor) {
            this.color = newColor;
        }

        public double getArea() {
                return Math.pow(radius, 2) * Math.PI;
            }

        @Override
        public String toString() {
            return "Circle{" +
                    "radius=" + radius +
                    ", color='" + color + '\'' +
                    '}';
        }
}
