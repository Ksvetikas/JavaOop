package object;

public class Debt {

    double balance = 0;
    double interestRate = 0;

    public Debt(double initialBalance, double initialInterestRate){

        this.balance = initialBalance;
        this.interestRate = initialInterestRate;
    }

    public void printBalance(){
        System.out.println("Your balance is : " + this.balance + " of money.");
    }

    public void waitOneYear(){
        this.balance = this.balance * this.interestRate;
    }
}
