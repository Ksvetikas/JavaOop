package object;

public class DecreasingCounter {

    private int value = 0;

    public DecreasingCounter(int newValue){
        this.value = newValue;
    }

    public void printValue(){
        System.out.println("New value: " + this.value + ".");
    }

    public void decrement(){
        if (this.value > 0) {
            this.value--;
            System.out.println("Oops! it's shrinking!");
        }else {
            this.value = 0;
        }
    }

    public void reset(){
        this.value = 0;
    }
}
