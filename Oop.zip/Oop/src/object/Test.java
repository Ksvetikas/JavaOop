package object;

public class Test {

    public static void main(String[] args) {


        Room naujas = new Room("201", 23);

        naujas.pilna();



        Whistle kuKu = new Whistle();

        kuKu.sound();


        Door naujos = new Door();
        naujos.knock();
        naujos.knock();


        Product daiktas = new Product("Banana", 1.1, 13);

        daiktas.printProduct();


        DecreasingCounter mazeja = new DecreasingCounter(10);

        mazeja.printValue();
        mazeja.decrement();
        mazeja.printValue();
        mazeja.reset();
        mazeja.decrement();
        mazeja.printValue();


        Debt skola = new Debt(120000, 1.01);

        skola.printBalance();
        skola.waitOneYear();
        skola.printBalance();


        Song tralialia = new Song("Aguonos", 100);

        System.out.println("Dainos pavadinimas " + tralialia.name() + ". ");
        System.out.println("Dainos ilgis " + tralialia.length() + "s.");


        Gauge kazkas = new Gauge();

        kazkas.increase();
        System.out.println(kazkas.value());
        kazkas.increase();
        System.out.println(kazkas.value());
        kazkas.decrease();
        System.out.println(kazkas.value());


        Circle apvalus = new Circle(2, "blue");

        System.out.println(apvalus.getArea());
        System.out.println(apvalus.toString());

        System.out.println(apvalus.getColor());

        Circle apvalus1 = new Circle(2);

        apvalus1.setColor("blue");
        System.out.println(apvalus1.toString());

    }

}
