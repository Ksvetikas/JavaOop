package object;

public class Song {

    String name = "";
    int seconds = 0;

    public Song(String newName, int length){
        this.name = newName;
        this.seconds = length;
    }

    public String name(){
        return this.name;
    }

    public int length(){
        return this.seconds;
    }
}
