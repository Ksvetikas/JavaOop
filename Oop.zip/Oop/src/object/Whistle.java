package object;

public class Whistle {

     private String sound= "pfffff pfffff";

     public Whistle(){

     }

    public Whistle(String whistle){

        this.sound = whistle;

    }

    public void sound(){
        System.out.println(this.sound);
    }
}
