package object;

public class Room {

    private String code = "101";
    private int seats =30;

    public Room(){

    }

    public Room(String classCode, int numberOfSeats){

            this.code = classCode;
            this.seats = numberOfSeats;

    }

    public void pilna(){
        System.out.println("Susirinko pilna " + this.code + " klase.");
    }
}

